from django.contrib import admin

from secondapp.models import Course

# Register your models here.
admin.site.register(Course)